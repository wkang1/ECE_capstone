<?php
    $output = shell_exec('./bash_script.sh');
    //shell_exec('./bash_script.sh');
    
    echo "<pre>$output</pre>";
?>